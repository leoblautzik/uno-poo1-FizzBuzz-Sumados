#include<stdio.h>

int main(){
    int suma=0;
    for(int i=1;i<=10;i++){
        suma+=i;
        printf("%d\n",suma);
    }

}

